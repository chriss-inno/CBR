--
-- Database: `cbr`
--

-- --------------------------------------------------------

--
-- Table structure for table `cbr_beneficiaries`
--

CREATE TABLE `cbr_beneficiaries` (
  `id` int(10) UNSIGNED NOT NULL,
  `progress_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_registration` date DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `family_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_females` int(11) DEFAULT NULL,
  `number_male` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_camps`
--

CREATE TABLE `cbr_camps` (
  `id` int(10) UNSIGNED NOT NULL,
  `reg_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `camp_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `zone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'working',
  `input_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_centres`
--

CREATE TABLE `cbr_centres` (
  `id` int(10) UNSIGNED NOT NULL,
  `centre_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `camp_id` int(11) NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'working',
  `input_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_clients`
--

CREATE TABLE `cbr_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `center_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `ward` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_disabled` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'No',
  `is_psn` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'No',
  `input_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_client_assessments`
--

CREATE TABLE `cbr_client_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `consultation_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `consultation_date` date DEFAULT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `medical_history` text COLLATE utf8_unicode_ci,
  `social_history` text COLLATE utf8_unicode_ci,
  `employment` text COLLATE utf8_unicode_ci,
  `skin_condition` text COLLATE utf8_unicode_ci,
  `daily_activities` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `joint_assessment` text COLLATE utf8_unicode_ci,
  `muscle_assessment` text COLLATE utf8_unicode_ci,
  `functional_assessment` text COLLATE utf8_unicode_ci,
  `problem_list` text COLLATE utf8_unicode_ci,
  `treatment` text COLLATE utf8_unicode_ci,
  `examiner_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `examiner_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_client_cases`
--

CREATE TABLE `cbr_client_cases` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `case_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `opened_date` date DEFAULT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `causes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_client_disabilities`
--

CREATE TABLE `cbr_client_disabilities` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `disability_diagnosis` text COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_client_referrals`
--

CREATE TABLE `cbr_client_referrals` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `referral_to` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referral_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `history` text COLLATE utf8_unicode_ci,
  `examination` text COLLATE utf8_unicode_ci,
  `referral_reason` text COLLATE utf8_unicode_ci,
  `referred_by_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referred_by_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referred_by_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `findings` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `findings_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `findings_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_countries`
--

CREATE TABLE `cbr_countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_departments`
--

CREATE TABLE `cbr_departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `department_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_disabilities`
--

CREATE TABLE `cbr_disabilities` (
  `id` int(10) UNSIGNED NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_districts`
--

CREATE TABLE `cbr_districts` (
  `id` int(10) UNSIGNED NOT NULL,
  `district_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `region_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbr_districts`
--

INSERT INTO `cbr_districts` (`id`, `district_name`, `region_id`, `created_at`, `updated_at`) VALUES
(1, 'Buhigwe', 1, '2016-06-28 12:51:11', '2016-06-28 12:51:11'),
(2, 'Kakonko', 1, '2016-06-28 12:51:37', '2016-06-28 12:51:37'),
(3, 'Kasulu Rural', 1, '2016-06-28 12:52:06', '2016-06-28 12:52:06'),
(4, 'Kasulu Urban', 1, '2016-06-28 12:52:38', '2016-06-28 12:52:38'),
(5, 'Kibondo', 1, '2016-06-28 12:52:57', '2016-06-28 12:52:57'),
(6, 'Uvinza', 1, '2016-06-28 12:53:31', '2016-06-28 12:53:31'),
(7, 'Meru', 2, '2016-06-29 11:25:31', '2016-06-29 11:25:31'),
(8, 'Arusha City', 2, '2016-06-29 11:25:54', '2016-06-29 11:25:54');

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_assessments`
--

CREATE TABLE `cbr_dump_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL,
  `center_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `district_id` int(11) DEFAULT NULL,
  `ward` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `consultation_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `consultation_date` date DEFAULT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `medical_history` text COLLATE utf8_unicode_ci,
  `social_history` text COLLATE utf8_unicode_ci,
  `employment` text COLLATE utf8_unicode_ci,
  `skin_condition` text COLLATE utf8_unicode_ci,
  `daily_activities` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `joint_assessment` text COLLATE utf8_unicode_ci,
  `muscle_assessment` text COLLATE utf8_unicode_ci,
  `functional_assessment` text COLLATE utf8_unicode_ci,
  `problem_list` text COLLATE utf8_unicode_ci,
  `treatment` text COLLATE utf8_unicode_ci,
  `examiner_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `examiner_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_beneficiaries`
--

CREATE TABLE `cbr_dump_beneficiaries` (
  `id` int(10) UNSIGNED NOT NULL,
  `progress_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_registration` date DEFAULT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `age` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `family_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `number_females` int(11) DEFAULT NULL,
  `number_male` int(11) DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_disabilities`
--

CREATE TABLE `cbr_dump_disabilities` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disability_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `disability_diagnosis` text COLLATE utf8_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8_unicode_ci,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_orthopedic_services`
--

CREATE TABLE `cbr_dump_orthopedic_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attendance_date` date NOT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `service_received` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_serviced` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_r_p_registers`
--

CREATE TABLE `cbr_dump_r_p_registers` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `assistance_provided` text COLLATE utf8_unicode_ci,
  `progress` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `error_descriptions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_r_s_registers`
--

CREATE TABLE `cbr_dump_r_s_registers` (
  `id` int(10) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_dump_social_needs`
--

CREATE TABLE `cbr_dump_social_needs` (
  `id` int(10) UNSIGNED NOT NULL,
  `progress_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assistance` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_descriptions` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_inventory_receiveds`
--

CREATE TABLE `cbr_inventory_receiveds` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `received_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `received_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_items_categories`
--

CREATE TABLE `cbr_items_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_items_disbursements`
--

CREATE TABLE `cbr_items_disbursements` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `disbursements_date` date NOT NULL,
  `disbursements_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_items_inventories`
--

CREATE TABLE `cbr_items_inventories` (
  `id` int(10) UNSIGNED NOT NULL,
  `item_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_migrations`
--

CREATE TABLE `cbr_migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbr_migrations`
--

INSERT INTO `cbr_migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2016_06_12_051433_entrust_setup_tables', 1),
('2016_06_15_071411_create_clients_table', 1),
('2016_06_16_070425_create_camps_table', 1),
('2016_06_16_070540_create_centres_table', 1),
('2016_06_16_070550_create_regions_table', 1),
('2016_06_16_070602_create_districts_table', 1),
('2016_06_16_071755_create_departments_table', 1),
('2016_06_16_073747_create_client_assessments_table', 1),
('2016_06_16_075419_create_client_disabilities_table', 1),
('2016_06_16_075715_create_disabilities_table', 1),
('2016_06_16_080202_create_countries_table', 1),
('2016_06_16_080559_create_site_setups_table', 1),
('2016_06_21_101431_create_client_referrals_table', 1),
('2016_06_21_102543_create_client_cases_table', 1),
('2016_06_21_104236_create_orthopedic_registers_table', 1),
('2016_06_24_092433_create_physiotherapy_registers_table', 1),
('2016_06_26_114008_create_p_s_n_assessments_table', 1),
('2016_06_26_115935_create_p_s_n_assistance_services_table', 1),
('2016_06_26_164300_create_p_s_n_case_reviews_table', 1),
('2016_06_26_224855_create_p_s_n_cases_table', 1),
('2016_06_26_232705_create_items_inventories_table', 1),
('2016_06_26_232740_create_items_disbursements_table', 1),
('2016_06_26_232758_create_items_categories_table', 1),
('2016_06_27_054311_create_inventory_receiveds_table', 1),
('2016_07_06_173835_create_dump_assessments_table', 1),
('2016_07_06_174121_create_dump_disabilities_table', 1),
('2016_07_07_062341_create_rehabilitation_registers_table', 1),
('2016_07_07_073257_create_dump_r_s_registers_table', 1),
('2016_07_07_082116_create_rehabilitation_progresses_table', 1),
('2016_07_07_085302_create_dump_r_p_registers_table', 1),
('2016_07_07_095615_create_orthopedic_services_table', 1),
('2016_07_07_095634_create_dump_orthopedic_services_table', 1),
('2016_07_07_183335_create_beneficiaries_table', 1),
('2016_07_07_200114_create_dump_beneficiaries_table', 1),
('2016_07_07_203644_create_social_needs_table', 1),
('2016_07_07_213412_create_dump_social_needs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cbr_orthopedic_registers`
--

CREATE TABLE `cbr_orthopedic_registers` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `date_attended` date DEFAULT NULL,
  `diagnosis` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `appliance_provided` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `measurement_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `remarks` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_orthopedic_services`
--

CREATE TABLE `cbr_orthopedic_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `attendance_date` date NOT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `service_received` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_serviced` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_password_resets`
--

CREATE TABLE `cbr_password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_permissions`
--

CREATE TABLE `cbr_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_permission_role`
--

CREATE TABLE `cbr_permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_physiotherapy_registers`
--

CREATE TABLE `cbr_physiotherapy_registers` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `causes` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_p_s_n_assessments`
--

CREATE TABLE `cbr_p_s_n_assessments` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(11) NOT NULL,
  `ration_card` text COLLATE utf8_unicode_ci,
  `family_size` text COLLATE utf8_unicode_ci,
  `progress_number` text COLLATE utf8_unicode_ci,
  `foster_care` text COLLATE utf8_unicode_ci,
  `nature_case` text COLLATE utf8_unicode_ci,
  `nature_case_other` text COLLATE utf8_unicode_ci,
  `family_relationship` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hist_problem` text COLLATE utf8_unicode_ci,
  `hist_problem_when` text COLLATE utf8_unicode_ci,
  `hist_causes` text COLLATE utf8_unicode_ci,
  `hist_problem_related` text COLLATE utf8_unicode_ci,
  `community_initiatives` text COLLATE utf8_unicode_ci,
  `action_planning` text COLLATE utf8_unicode_ci,
  `general_remarks` text COLLATE utf8_unicode_ci,
  `follow_up` text COLLATE utf8_unicode_ci,
  `caregiver_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `caregiver_date` date DEFAULT NULL,
  `interviewer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interviewer_date` date DEFAULT NULL,
  `reviewer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reviewer_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_p_s_n_assistance_services`
--

CREATE TABLE `cbr_p_s_n_assistance_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `psn_id` int(11) NOT NULL,
  `service_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_p_s_n_cases`
--

CREATE TABLE `cbr_p_s_n_cases` (
  `id` int(10) UNSIGNED NOT NULL,
  `psn_id` int(11) NOT NULL,
  `needs_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_p_s_n_case_reviews`
--

CREATE TABLE `cbr_p_s_n_case_reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `psn_id` int(11) NOT NULL,
  `needs_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_regions`
--

CREATE TABLE `cbr_regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `region_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbr_regions`
--

INSERT INTO `cbr_regions` (`id`, `region_name`, `created_at`, `updated_at`) VALUES
(1, 'Kigoma', '2016-06-28 12:50:38', '2016-06-28 12:50:38'),
(2, 'Arusha', '2016-06-29 11:24:48', '2016-06-29 11:24:48'),
(3, 'Dar es Salaam', '2016-06-29 11:41:53', '2016-06-29 11:41:53'),
(4, 'Dodoma', '2016-06-29 11:42:12', '2016-06-29 11:42:12'),
(5, 'Geita', '2016-06-29 11:42:28', '2016-06-29 11:42:28'),
(6, 'Iringa', '2016-06-29 11:42:49', '2016-06-29 11:42:49'),
(7, 'Katavi', '2016-06-29 11:48:17', '2016-06-29 11:48:17'),
(8, 'Kilimanjaro', '2016-06-29 11:48:33', '2016-06-29 11:48:33'),
(9, 'Lindi', '2016-06-29 11:48:53', '2016-06-29 11:48:53'),
(10, 'Manyara', '2016-06-29 11:49:07', '2016-06-29 11:49:07'),
(11, 'Mara', '2016-06-29 11:49:22', '2016-06-29 11:49:22'),
(12, 'Mbeya', '2016-06-29 11:49:45', '2016-06-29 11:49:45'),
(13, 'Morogoro', '2016-06-29 11:49:59', '2016-06-29 11:49:59'),
(14, 'Mtwara', '2016-06-29 11:50:16', '2016-06-29 11:50:16'),
(15, 'Mwanza', '2016-06-29 11:50:33', '2016-06-29 11:50:33'),
(16, 'Njombe', '2016-06-29 11:50:48', '2016-06-29 11:50:48'),
(17, 'Pemba North', '2016-06-29 11:51:02', '2016-06-29 11:51:32'),
(18, 'Pemba South', '2016-06-29 11:51:46', '2016-06-29 11:51:46'),
(19, 'Pwani', '2016-06-29 11:52:00', '2016-06-29 11:52:00'),
(20, 'Rukwa', '2016-06-29 11:52:15', '2016-06-29 11:52:15'),
(21, 'Ruvuma', '2016-06-29 11:52:31', '2016-06-29 11:52:31'),
(22, 'Shinyanga', '2016-06-29 11:52:49', '2016-06-29 11:52:49'),
(23, 'Simiyu', '2016-06-29 11:53:02', '2016-06-29 11:53:02'),
(24, 'Singida', '2016-06-29 11:53:16', '2016-06-29 11:53:16'),
(25, 'Tabora', '2016-06-29 11:54:27', '2016-06-29 11:54:27'),
(26, 'Tanga', '2016-06-29 11:54:42', '2016-06-29 11:54:42'),
(27, 'Zanzibar North', '2016-06-29 11:54:58', '2016-06-29 11:54:58'),
(28, 'Zanzibar South', '2016-06-29 11:55:13', '2016-06-29 11:55:13'),
(29, 'Zanzibar Urban West', '2016-06-29 11:55:36', '2016-06-29 11:55:36');

-- --------------------------------------------------------

--
-- Table structure for table `cbr_rehabilitation_progresses`
--

CREATE TABLE `cbr_rehabilitation_progresses` (
  `id` int(10) UNSIGNED NOT NULL,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `assistance_provided` text COLLATE utf8_unicode_ci,
  `progress` text COLLATE utf8_unicode_ci,
  `remarks` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_rehabilitation_registers`
--

CREATE TABLE `cbr_rehabilitation_registers` (
  `id` int(10) UNSIGNED NOT NULL,
  `attendance_date` date NOT NULL,
  `diagnosis` text COLLATE utf8_unicode_ci,
  `file_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_roles`
--

CREATE TABLE `cbr_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_role_user`
--

CREATE TABLE `cbr_role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_site_setups`
--

CREATE TABLE `cbr_site_setups` (
  `id` int(10) UNSIGNED NOT NULL,
  `organization_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `app_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `profile` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_social_needs`
--

CREATE TABLE `cbr_social_needs` (
  `id` int(10) UNSIGNED NOT NULL,
  `progress_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `assistance` text COLLATE utf8_unicode_ci,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cbr_users`
--

CREATE TABLE `cbr_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `department_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `campus_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `locked` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `last_success_login` datetime DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cbr_users`
--

INSERT INTO `cbr_users` (`id`, `first_name`, `middle_name`, `last_name`, `phone`, `email`, `address`, `department_id`, `campus_id`, `designation`, `status`, `locked`, `user_name`, `password`, `last_login`, `last_logout`, `last_success_login`, `profile_image`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', NULL, 'Administrator', '', 'chriss.innocent@gmail.com', '', '', '', '', 'Active', '', 'admin', '$2y$10$j1NskbriR7oLQpGLNT.cH.dLCKmGvKzckUsKQ/ZzNSRsy4ZEtU4Le', NULL, NULL, '2016-07-07 11:16:53', NULL, NULL, NULL, '2016-07-07 20:16:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cbr_beneficiaries`
--
ALTER TABLE `cbr_beneficiaries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `beneficiaries_progress_number_unique` (`progress_number`);

--
-- Indexes for table `cbr_camps`
--
ALTER TABLE `cbr_camps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_centres`
--
ALTER TABLE `cbr_centres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_clients`
--
ALTER TABLE `cbr_clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_file_number_unique` (`file_number`);

--
-- Indexes for table `cbr_client_assessments`
--
ALTER TABLE `cbr_client_assessments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_client_cases`
--
ALTER TABLE `cbr_client_cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_client_disabilities`
--
ALTER TABLE `cbr_client_disabilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_client_referrals`
--
ALTER TABLE `cbr_client_referrals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_countries`
--
ALTER TABLE `cbr_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_departments`
--
ALTER TABLE `cbr_departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_disabilities`
--
ALTER TABLE `cbr_disabilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_districts`
--
ALTER TABLE `cbr_districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_assessments`
--
ALTER TABLE `cbr_dump_assessments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_beneficiaries`
--
ALTER TABLE `cbr_dump_beneficiaries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_disabilities`
--
ALTER TABLE `cbr_dump_disabilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_orthopedic_services`
--
ALTER TABLE `cbr_dump_orthopedic_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_r_p_registers`
--
ALTER TABLE `cbr_dump_r_p_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_r_s_registers`
--
ALTER TABLE `cbr_dump_r_s_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_dump_social_needs`
--
ALTER TABLE `cbr_dump_social_needs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_inventory_receiveds`
--
ALTER TABLE `cbr_inventory_receiveds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_items_categories`
--
ALTER TABLE `cbr_items_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_items_disbursements`
--
ALTER TABLE `cbr_items_disbursements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_items_inventories`
--
ALTER TABLE `cbr_items_inventories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_orthopedic_registers`
--
ALTER TABLE `cbr_orthopedic_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_orthopedic_services`
--
ALTER TABLE `cbr_orthopedic_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_password_resets`
--
ALTER TABLE `cbr_password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `cbr_permissions`
--
ALTER TABLE `cbr_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `cbr_permission_role`
--
ALTER TABLE `cbr_permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `cbr_physiotherapy_registers`
--
ALTER TABLE `cbr_physiotherapy_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_p_s_n_assessments`
--
ALTER TABLE `cbr_p_s_n_assessments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_p_s_n_assistance_services`
--
ALTER TABLE `cbr_p_s_n_assistance_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_p_s_n_cases`
--
ALTER TABLE `cbr_p_s_n_cases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_p_s_n_case_reviews`
--
ALTER TABLE `cbr_p_s_n_case_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_regions`
--
ALTER TABLE `cbr_regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_rehabilitation_progresses`
--
ALTER TABLE `cbr_rehabilitation_progresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_rehabilitation_registers`
--
ALTER TABLE `cbr_rehabilitation_registers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_roles`
--
ALTER TABLE `cbr_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `cbr_role_user`
--
ALTER TABLE `cbr_role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `cbr_site_setups`
--
ALTER TABLE `cbr_site_setups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_social_needs`
--
ALTER TABLE `cbr_social_needs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cbr_users`
--
ALTER TABLE `cbr_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_user_name_unique` (`user_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cbr_beneficiaries`
--
ALTER TABLE `cbr_beneficiaries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_camps`
--
ALTER TABLE `cbr_camps`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_centres`
--
ALTER TABLE `cbr_centres`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_clients`
--
ALTER TABLE `cbr_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_client_assessments`
--
ALTER TABLE `cbr_client_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_client_cases`
--
ALTER TABLE `cbr_client_cases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_client_disabilities`
--
ALTER TABLE `cbr_client_disabilities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_client_referrals`
--
ALTER TABLE `cbr_client_referrals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_countries`
--
ALTER TABLE `cbr_countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_departments`
--
ALTER TABLE `cbr_departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_disabilities`
--
ALTER TABLE `cbr_disabilities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_districts`
--
ALTER TABLE `cbr_districts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `cbr_dump_assessments`
--
ALTER TABLE `cbr_dump_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_beneficiaries`
--
ALTER TABLE `cbr_dump_beneficiaries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_disabilities`
--
ALTER TABLE `cbr_dump_disabilities`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_orthopedic_services`
--
ALTER TABLE `cbr_dump_orthopedic_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_r_p_registers`
--
ALTER TABLE `cbr_dump_r_p_registers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_r_s_registers`
--
ALTER TABLE `cbr_dump_r_s_registers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_dump_social_needs`
--
ALTER TABLE `cbr_dump_social_needs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_inventory_receiveds`
--
ALTER TABLE `cbr_inventory_receiveds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_items_categories`
--
ALTER TABLE `cbr_items_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_items_disbursements`
--
ALTER TABLE `cbr_items_disbursements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_items_inventories`
--
ALTER TABLE `cbr_items_inventories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_orthopedic_registers`
--
ALTER TABLE `cbr_orthopedic_registers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_orthopedic_services`
--
ALTER TABLE `cbr_orthopedic_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_permissions`
--
ALTER TABLE `cbr_permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_physiotherapy_registers`
--
ALTER TABLE `cbr_physiotherapy_registers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_p_s_n_assessments`
--
ALTER TABLE `cbr_p_s_n_assessments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_p_s_n_assistance_services`
--
ALTER TABLE `cbr_p_s_n_assistance_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_p_s_n_cases`
--
ALTER TABLE `cbr_p_s_n_cases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_p_s_n_case_reviews`
--
ALTER TABLE `cbr_p_s_n_case_reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_regions`
--
ALTER TABLE `cbr_regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `cbr_rehabilitation_progresses`
--
ALTER TABLE `cbr_rehabilitation_progresses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_rehabilitation_registers`
--
ALTER TABLE `cbr_rehabilitation_registers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_roles`
--
ALTER TABLE `cbr_roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_site_setups`
--
ALTER TABLE `cbr_site_setups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_social_needs`
--
ALTER TABLE `cbr_social_needs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cbr_users`
--
ALTER TABLE `cbr_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cbr_permission_role`
--
ALTER TABLE `cbr_permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `cbr_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `cbr_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cbr_role_user`
--
ALTER TABLE `cbr_role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `cbr_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `cbr_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
