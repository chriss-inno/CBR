<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DumpRSRegister extends Model
{
    //
}
